
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import json

from ai_generator import generate_payloads

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RequestInput(BaseModel):
    body: dict
    count: int = 10

@app.post("/generate")
def generate(input: RequestInput):
    payloads = generate_payloads(input.body, input.count)

    with open("data.json", "w") as f:
        json.dump(payloads, f, indent=2)

    return {"message": "Generated", "count": len(payloads)}
