
import random
import uuid
from datetime import datetime

def smart_generate(key, value):
    k = key.lower()

    if "id" in k:
        return str(uuid.uuid4())

    if "date" in k:
        return datetime.today().strftime("%Y-%m-%d")

    if "status" in k:
        return random.choice(["ACTIVE", "INACTIVE", "PENDING"])

    if "name" in k:
        return random.choice(["John", "Alice", "David"])

    if isinstance(value, int):
        return random.randint(1, 1000)

    if isinstance(value, float):
        return round(random.uniform(1, 1000), 2)

    if isinstance(value, str):
        return "sample"

    return value


def generate_dynamic(data):
    if isinstance(data, dict):
        return {k: generate_dynamic(v) if isinstance(v, (dict, list))
                else smart_generate(k, v)
                for k, v in data.items()}

    elif isinstance(data, list):
        return [generate_dynamic(data[0])] if data else []

    return data


def generate_payloads(template, n=10):
    return [generate_dynamic(template) for _ in range(n)]
