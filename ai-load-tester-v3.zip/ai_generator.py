
import random
import uuid
from datetime import datetime

def apply_rule(rule):
    if rule == "uuid":
        return str(uuid.uuid4())
    if rule == "today":
        return datetime.today().strftime("%Y-%m-%d")
    if rule.startswith("enum:"):
        options = rule.split(":")[1].split("|")
        return random.choice(options)
    if rule == "professional":
        reasons = [
            "Data refresh required for compliance",
            "Periodic update for accuracy",
            "System triggered refresh",
            "Manual correction request"
        ]
        return random.choice(reasons)
    return "sample"

def generate_dynamic(data, rules, path=""):
    if isinstance(data, dict):
        result = {}
        for k, v in data.items():
            current_path = f"{path}.{k}" if path else k
            if current_path in rules:
                result[k] = apply_rule(rules[current_path])
            else:
                result[k] = generate_dynamic(v, rules, current_path)
        return result
    elif isinstance(data, list):
        return [generate_dynamic(data[0], rules, path)] if data else []
    return data

def generate_payloads(template, rules, n=10):
    return [generate_dynamic(template, rules) for _ in range(n)]
