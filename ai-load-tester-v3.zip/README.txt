AI Load Tester V3 (Smart UI)

Steps:
1. pip install -r requirements.txt
2. python -m uvicorn app:app --reload
3. Open index.html
4. Click 'Detect Fields'
5. Select rules from dropdown
6. Click Generate
