import random, uuid, json, os
from datetime import datetime

RULES_FILE = "rules_memory.json"

US_ZIPCODES = ["10001","30301","60601","94105","73301","90001","02101"]
PSD_CODES = ["101001","202002","303003","404004","505005"]

REASONS = [
    "Compliance update required",
    "Scheduled system refresh",
    "Manual correction initiated",
    "Data synchronization process"
]

def load_memory():
    if not os.path.exists(RULES_FILE):
        return {}
    with open(RULES_FILE) as f:
        return json.load(f)

def save_memory(memory):
    with open(RULES_FILE, "w") as f:
        json.dump(memory, f, indent=2)

def normalize_key(field):
    field = field.lower()
    if "zip" in field: return "zip"
    if "psd" in field: return "psd"
    if "date" in field: return "date"
    if "id" in field: return "id"
    if "type" in field or "status" in field: return "enum"
    return field

def learn_rules(rules):
    memory = load_memory()
    for path, rule in rules.items():
        key = normalize_key(path)
        memory.setdefault(key, {})
        memory[key][rule] = memory[key].get(rule, 0) + 1
    save_memory(memory)

def interpret_prompt(prompt):
    p = prompt.lower().strip()
    if p == "uuid": return str(uuid.uuid4())
    if "date" in p: return datetime.today().strftime("%Y-%m-%d")
    if "psd" in p: return random.choice(PSD_CODES)
    if "zip" in p: return random.choice(US_ZIPCODES)
    if "home" in p or "work" in p or "both" in p:
        return random.choice(["Home","Work","Both"])
    if "reason" in p:
        return random.choice(REASONS)
    if "enum:" in p:
        return random.choice(p.split(":")[1].split("|"))
    return "sample"

def generate_dynamic(data, rules, path=""):
    if isinstance(data, dict):
        result = {}
        for k, v in data.items():
            current = f"{path}.{k}" if path else k
            if current in rules:
                val = interpret_prompt(rules[current])
                if isinstance(v, list): result[k] = [val]
                else: result[k] = val
            elif isinstance(v, str):
                try:
                    parsed = json.loads(v)
                    result[k] = json.dumps(generate_dynamic(parsed, rules, current))
                except:
                    result[k] = v
            elif isinstance(v, (dict,list)):
                result[k] = generate_dynamic(v, rules, current)
            else:
                result[k] = v
        return result
    elif isinstance(data, list):
        return [generate_dynamic(data[0], rules, path)]
    return data

def generate_payloads(template, rules, n=10):
    return [generate_dynamic(template, rules) for _ in range(n)]
