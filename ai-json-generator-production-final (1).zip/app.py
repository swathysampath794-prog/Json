from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from ai_generator import generate_payloads, learn_rules, load_memory

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Input(BaseModel):
    body: dict
    rules: dict = {}
    count: int = 10

@app.post("/generate")
def generate(input: Input):
    learn_rules(input.rules)
    return generate_payloads(input.body, input.rules, input.count)

@app.get("/rules-memory")
def rules():
    return load_memory()
