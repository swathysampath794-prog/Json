
from fastapi import FastAPI
from pydantic import BaseModel
import json
from ai_generator import generate_payloads
from k6_generator import generate_k6_script

app = FastAPI()

class RequestInput(BaseModel):
    url: str
    body: dict
    count: int = 10

@app.post("/generate")
def generate(input: RequestInput):
    payloads = generate_payloads(input.body, input.count)

    with open("data.json", "w") as f:
        json.dump(payloads, f, indent=2)

    script = generate_k6_script(input.url)
    with open("script.js", "w") as f:
        f.write(script)

    return {"message": "AI payloads generated", "count": len(payloads)}
