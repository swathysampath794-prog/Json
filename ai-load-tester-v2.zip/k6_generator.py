
def generate_k6_script(url):
    return f'''
import http from 'k6/http';
import {{ sleep }} from 'k6';

const data = JSON.parse(open('./data.json'));

export let options = {{
  vus: 20,
  duration: '1m',
}};

export default function () {{
  const payload = JSON.stringify(data[Math.floor(Math.random()*data.length)]);
  http.post('{url}', payload, {{ headers: {{ 'Content-Type': 'application/json' }} }});
  sleep(0.5);
}}
'''
