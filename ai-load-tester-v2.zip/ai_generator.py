
import random
from faker import Faker
from datetime import timedelta

fake = Faker()

COMMON_ENUMS = {
    "status": ["ACTIVE", "INACTIVE", "PENDING"],
    "type": ["ADMIN", "USER", "GUEST"],
    "role": ["ADMIN", "USER", "MANAGER"],
    "state": ["SUCCESS", "FAILED", "PROCESSING"]
}

def detect_type(key, value):
    k = key.lower()

    if k in COMMON_ENUMS:
        return "enum"

    if "email" in k:
        return "email"
    if "name" in k:
        return "name"
    if "phone" in k:
        return "phone"
    if "city" in k:
        return "city"
    if "startdate" in k:
        return "start_date"
    if "enddate" in k:
        return "end_date"
    if "date" in k:
        return "date"
    if "id" in k:
        return "id"
    if "amount" in k or "price" in k:
        return "amount"

    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"

    return "string"

def generate_value(key, t, context):
    if t == "enum":
        return random.choice(COMMON_ENUMS.get(key.lower(), ["UNKNOWN"]))
    if t == "email":
        return fake.email()
    if t == "name":
        return fake.name()
    if t == "phone":
        return fake.phone_number()
    if t == "city":
        return fake.city()
    if t == "date":
        return str(fake.date())
    if t == "start_date":
        start = fake.date_between(start_date='-30d', end_date='today')
        context["start_date"] = start
        return str(start)
    if t == "end_date":
        if "start_date" in context:
            return str(context["start_date"] + timedelta(days=random.randint(1, 10)))
        return str(fake.date())
    if t == "amount":
        return round(random.uniform(10, 10000), 2)
    if t == "id":
        return random.randint(1000, 9999)
    if t == "int":
        return random.randint(1, 1000)
    if t == "float":
        return round(random.uniform(1, 1000), 2)
    if t == "bool":
        return random.choice([True, False])

    return fake.word()

def generate_payload(template, context=None):
    if context is None:
        context = {}

    if isinstance(template, dict):
        return {
            k: generate_payload(v, context) if isinstance(v, (dict, list))
            else generate_value(k, detect_type(k, v), context)
            for k, v in template.items()
        }
    elif isinstance(template, list):
        return [generate_payload(template[0], context)] if template else []

    return template

def generate_payloads(template, n=10):
    return [generate_payload(template, {}) for _ in range(n)]
