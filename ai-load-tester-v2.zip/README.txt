AI Load Tester V2

1. Install Python 3.9+

2. Install deps:
pip install -r requirements.txt

3. Run backend:
uvicorn app:app --reload

4. Open index.html

5. Generate payloads

6. Install k6: https://k6.io

7. Run:
k6 run script.js
