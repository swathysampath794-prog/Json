from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from ai_generator import generate_payloads

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Input(BaseModel):
    body: dict
    rules: dict = {}
    count: int = 10

@app.post("/generate")
def generate(input: Input):
    return generate_payloads(input.body, input.rules, input.count)
