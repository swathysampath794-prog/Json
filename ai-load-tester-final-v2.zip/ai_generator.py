import random
import uuid
import json
from datetime import datetime

US_ZIPCODES = ["10001","30301","60601","94105","73301","90001","02101"]
PSD_CODES = ["101001","202002","303003","404004","505005"]

REASONS = [
    "Compliance update required",
    "Scheduled system refresh",
    "Manual correction initiated",
    "Data synchronization process"
]

def interpret_prompt(prompt):
    p = prompt.lower()

    if "uuid" in p or "id" in p:
        return str(uuid.uuid4())

    if "date" in p or "today" in p:
        return datetime.today().strftime("%Y-%m-%d")

    if "psd" in p:
        return random.choice(PSD_CODES)

    if "zip" in p:
        return random.choice(US_ZIPCODES)

    if "home" in p or "work" in p or "both" in p:
        return random.choice(["Home","Work","Both"])

    if "reason" in p or "professional" in p:
        return random.choice(REASONS)

    if "enum:" in p:
        return random.choice(p.split(":")[1].split("|"))

    return "sample"

def generate_dynamic(data, rules, path=""):
    if isinstance(data, dict):
        result = {}
        for k, v in data.items():
            current_path = f"{path}.{k}" if path else k

            # apply rule
            if current_path in rules:
                result[k] = interpret_prompt(rules[current_path])

            # handle JSON string fields safely
            elif isinstance(v, str):
                try:
                    parsed = json.loads(v)
                    updated = generate_dynamic(parsed, rules, current_path)
                    result[k] = json.dumps(updated)
                except:
                    result[k] = v

            elif isinstance(v, (dict, list)):
                result[k] = generate_dynamic(v, rules, current_path)
            else:
                result[k] = v

        return result

    elif isinstance(data, list):
        return [generate_dynamic(data[0], rules, path)] if data else []

    return data

def generate_payloads(template, rules, n=10):
    return [generate_dynamic(template, rules) for _ in range(n)]
